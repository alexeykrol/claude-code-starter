# SNAPSHOT — {{PROJECT_NAME}}

*Last updated: {{DATE}}*

## Current State

**Version:** {{PROJECT_VERSION}}
**Status:** Initial setup with Claude Code Starter Framework
**Branch:** {{CURRENT_BRANCH}}

## Project Overview

**Name:** {{PROJECT_NAME}}
**Description:** {{PROJECT_DESCRIPTION}}

**Tech Stack:**
{{TECH_STACK}}

## Current Structure

```
{{PROJECT_NAME}}/
{{PROJECT_STRUCTURE}}
```

## Recent Progress

- [x] Initialized Claude Code Starter Framework
- [ ] Add your completed tasks here

## Active Work

- [ ] Add your current tasks here

## Next Steps

- [ ] Add your planned tasks here

## Key Concepts

{{PROJECT_KEY_CONCEPTS}}

---
*Quick-start context for AI sessions*
